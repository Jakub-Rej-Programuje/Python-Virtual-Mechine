import tkinter as tk
import subprocess
import pygame
import sys
import os

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.master.geometry("250x308")
        self.master.eval('tk::PlaceWindow %s center' % self.master.winfo_toplevel())
        self.pack()
        self.create_widgets()
        self.master.title("Python Virtual Machine ShortCut")

    def create_widgets(self):
        self.portal_label = tk.Label(self, text="Vyberte zkratku:") 
        self.portal_label.pack(side="top")                          

        self.diktafon_button = tk.Button(self, text="      Internetové Úložiště (beta)        ", command=self.open_int)
        self.diktafon_button.pack()
        
        self.text_editor_button = tk.Button(self, text="Hlasový Asistent (jen v angličnině)", command=self.open_v)
        self.text_editor_button.pack()

        self.czk_to_eur_button = tk.Button(self, text="            Převod z EUR do CZK            ", command=self.open_czk_to_eur_converter)
        self.czk_to_eur_button.pack()
        
        self.calculator_button = tk.Button(self, text="       Kalkulačka        ", command=self.open_calculator_converter)
        self.calculator_button.pack

        self.music_player_button = tk.Button(self, text="                 Přehrávač Písní                  ", command=self.open_music_player_converter)
        self.music_player_button.pack()
  
        self.text_editor_button = tk.Button(self, text="                    Textový Editor                 ", command=self.open_text_editor)
        self.text_editor_button.pack()

        # Vytvoření tlačítka pro diktafon
        self.diktafon_button = tk.Button(self, text="                       Diktafon                        ", command=self.open_diktafon_converter)
        self.diktafon_button.pack()

        self.diktafon_button = tk.Button(self, text="                        Stopky                          ", command=self.open_stop)
        self.diktafon_button.pack()

        self.text_editor_button = tk.Button(self, text="                         Hodiny                        ", command=self.open_clock)
        self.text_editor_button.pack()

        self.text_editor_label = tk.Label(self, text="Vyberte hru:")
        self.text_editor_label.pack()

        self.text_editor_button = tk.Button(self, text="                  Piškvorky                  ", command=self.open_tictactoe)
        self.text_editor_button.pack()

        self.text_editor_button = tk.Button(self, text="                  Střílečka                    ", command=self.open_shoot)
        self.text_editor_button.pack()

        print("Otevírání...")
    def open_music_player_converter(self):
        script_path = os.path.join(sys.path[0], "Programs", "přehrávač-písní.py")
        subprocess.Popen([sys.executable, script_path])

    def open_v(self):
        script_path = os.path.join(sys.path[0], "Programs", "pvm-Voice-Assistent.py")
        subprocess.Popen([sys.executable, script_path])

    def open_int(self):
        script_path = os.path.join(sys.path[0], "Programs", "storage.py")
        subprocess.Popen([sys.executable, script_path])


    def open_shoot(self):
        script_path = os.path.join(sys.path[0], "Programs", "Shooter.py")
        subprocess.Popen([sys.executable, script_path])

    def open_tictactoe(self):
        script_path = os.path.join(sys.path[0], "Programs", "Tic-Tac-Toe.py")
        subprocess.Popen([sys.executable, script_path])

    def open_calculator_converter(self):
        script_path = os.path.join(sys.path[0], "Programs", "kalkulačka.py")
        subprocess.Popen([sys.executable, script_path])

    def open_text_editor(self):
        script_path = os.path.join(sys.path[0], "Programs", "textový-editor.py")
        subprocess.Popen([sys.executable, script_path])

    def open_stop(self):
        script_path = os.path.join(sys.path[0], "Programs", "stopky.py")
        subprocess.Popen([sys.executable, script_path])


    def open_clock(self):
        script_path = os.path.join(sys.path[0], "Programs", "hodiny.py")
        subprocess.Popen([sys.executable, script_path])


    def open_diktafon_converter(self):
        script_path = os.path.join(sys.path[0], "Programs", "diktafon.py")
        subprocess.Popen([sys.executable, script_path])

    def open_czk_to_eur_converter(self):
        # Vytvoření nového okna pro převod z CZK na eura
        self.czk_to_eur_window = tk.Toplevel(self.master)
        self.czk_to_eur_window.title("Převod z EUR do CZK")

        # Vytvoření labelu pro zadání částky v CZK
        self.amount_label = tk.Label(self.czk_to_eur_window, text="Částka v EUR:")
        self.amount_label.pack()

        # Vytvoření entry pro zadání částky v CZK
        self.amount_entry = tk.Entry(self.czk_to_eur_window)
        self.amount_entry.pack()

        # Vytvoření tlačítka pro převod z CZK na eura
        self.convert_button = tk.Button(self.czk_to_eur_window, text="EUR do CZK", command=self.convert_czk_to_eur)
        self.convert_button.pack()

        # Vytvoření labelu pro zobrazení výsledku převodu
        self.result_label = tk.Label(self.czk_to_eur_window, text="")
        self.result_label.pack()

    def convert_czk_to_eur(self):
        # Získání aktuálního kurzu CZK/EUR
        # TODO: přidat funkci pro získání aktuálního kurzu
        czk_to_eur_rate = 25.5

        # Výpočet převodu
        czk_amount = float(self.amount_entry.get())
        eur_amount = round(czk_amount / czk_to_eur_rate, 2)

        # Zobrazení výsledku
        result_text = f"{czk_amount:.2f} CZK = {eur_amount:.2f} EUR"
        self.result_label.configure(text=result_text)

# Vytvoření instance aplikace Tkinter
root = tk.Tk()
app = Application(master=root)
app.mainloop()

# Ukončení knihovny Pygame
pygame.quit()

#end
print("ukončování...")
