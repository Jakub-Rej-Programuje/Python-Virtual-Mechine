import tkinter as tk
import sounddevice as sd
import soundfile as sf
import numpy as np
from tkinter import filedialog

class Recorder:
    def __init__(self):
        self.frames = []
        self.samplerate = 44100
        self.channels = 2

    def start_recording(self):
        self.frames = []
        sd.default.samplerate = self.samplerate
        sd.default.channels = self.channels
        self.stream = sd.InputStream(callback=self._callback)
        self.stream.start()

    def stop_recording(self):
        self.stream.stop()
        self.stream.close()

    def _callback(self, indata, frames, time, status):
        if status:
            print(status, file=tk.stderr)
        self.frames.append(indata.copy())

    def save_recording(self, filename):
        data = np.concatenate(self.frames)
        sf.write(filename, data, self.samplerate, subtype='PCM_24')

class App:
    def __init__(self, master):
        self.recorder = Recorder()
        self.filename = tk.StringVar()
        self.filename.set("recording.wav")
        self.filepath = tk.StringVar()
        self.filepath.set("")

        tk.Label(master, text="Diktafon", font=("Helvetica", 20)).grid(row=0, column=0, columnspan=2, pady=10)
        tk.Label(master, text="Nahrávání:").grid(row=1, column=0, pady=5)
        tk.Entry(master, textvariable=self.filename).grid(row=1, column=1, pady=5)
        tk.Label(master, text="Uložit jako:").grid(row=2, column=0, pady=5)
        tk.Entry(master, textvariable=self.filepath).grid(row=2, column=1, pady=5)
        tk.Button(master, text="Start", command=self.start_recording).grid(row=3, column=0, pady=5)
        tk.Button(master, text="Stop", command=self.stop_recording).grid(row=3, column=1, pady=5)
        tk.Button(master, text="Uložit", command=self.save_recording).grid(row=4, column=0, columnspan=2, pady=10)

    def start_recording(self):
        self.recorder.start_recording()

    def stop_recording(self):
        self.recorder.stop_recording()

    def save_recording(self):
        filename = self.filename.get()
        initialdir = self.filepath.get()
        filepath = filedialog.askdirectory(initialdir=initialdir, title="Vyberte cestu pro uložení souboru")
        if filepath:
            filename = filepath + '/' + filename
            self.recorder.save_recording(filename)
        self.master.title("Diktafon")
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
