import pygame
import random

# Inicializace Pygame
pygame.init()

# Nastavení velikosti okna a pozadí
WIDTH = 300
HEIGHT = 300
BACKGROUND_COLOR = (255, 255, 255)
screen = pygame.display.set_mode((WIDTH, HEIGHT))
screen.fill(BACKGROUND_COLOR)

# Nastavení fontu pro textové zprávy
FONT = pygame.font.SysFont('Arial', 50)

# Konstanty pro hrací pole
ROW_COUNT = 3
COLUMN_COUNT = 3
SQUARE_SIZE = 100
X_COLOR = (255, 0, 0)
O_COLOR = (0, 0, 255)

# Vytvoření okna
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tic Tac Toe")

# Funkce pro vytvoření nové hry
def new_game():
    global board, turn
    board = [[' ' for i in range(COLUMN_COUNT)] for j in range(ROW_COUNT)]
    turn = random.choice(['X', 'O'])
    draw_board()

# Funkce pro kreslení hracího pole
def draw_board():
    screen.fill(BACKGROUND_COLOR)
    for row in range(ROW_COUNT):
        for col in range(COLUMN_COUNT):
            pygame.draw.rect(screen, (0, 0, 0), (col*SQUARE_SIZE, row*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 2)
            if board[row][col] == 'X':
                pygame.draw.line(screen, X_COLOR, (col*SQUARE_SIZE+10, row*SQUARE_SIZE+10), (col*SQUARE_SIZE+SQUARE_SIZE-10, row*SQUARE_SIZE+SQUARE_SIZE-10), 2)
                pygame.draw.line(screen, X_COLOR, (col*SQUARE_SIZE+10, row*SQUARE_SIZE+SQUARE_SIZE-10), (col*SQUARE_SIZE+SQUARE_SIZE-10, row*SQUARE_SIZE+10), 2)
            elif board[row][col] == 'O':
                pygame.draw.circle(screen, O_COLOR, (col*SQUARE_SIZE+SQUARE_SIZE//2, row*SQUARE_SIZE+SQUARE_SIZE//2), SQUARE_SIZE//2-10, 2)
    pygame.display.update()

# Funkce pro získání souřadnic pole podle pozice myši
def get_square(mouse_pos):
    for row in range(ROW_COUNT):
        for col in range(COLUMN_COUNT):
            if mouse_pos[0] > col*SQUARE_SIZE and mouse_pos[0] < col*SQUARE_SIZE+SQUARE_SIZE:
                if mouse_pos[1] > row*SQUARE_SIZE and mouse_pos[1] < row*SQUARE_SIZE+SQUARE_SIZE:
                    return (row, col)
    return None

# Funkce pro ověření, zda je tah platný
def is_valid_move(square):
    if board[square[0]][square[1]] == ' ':
        return True
    return False

# Funkce pro ověření, zda hra skončila výhrou někoho nebo remízou
def is_game_over():
        # Kontrola sloupců
        for col in range(COLUMN_COUNT):
            if board[0][col] == board[1][col] == board[2][col] and board[0][col] != ' ':
                return True
        # Kontrola diagonál
        if board[0][0] == board[1][1] == board[2][2] and board[0][0] != ' ':
            return True
        if board[0][2] == board[1][1] == board[2][0] and board[0][2] != ' ':
            return True
        # Kontrola remízy
        for row in range(ROW_COUNT):
            for col in range(COLUMN_COUNT):
                if board[row][col] == ' ':
                    return False
        return True

# Funkce pro tah hráče
def player_move(square):
    global turn
    if is_valid_move(square):
        board[square[0]][square[1]] = turn
        draw_board()
        if is_game_over():
            message = FONT.render("Hra skončila!", True, (0, 0, 0))
            message_rect = message.get_rect(center=(WIDTH/2, HEIGHT/2))
            screen.blit(message, message_rect)
            pygame.display.update()
        else:
            if turn == 'X':
                turn = 'O'
            else:
                turn = 'X'
            bot_move()

# Funkce pro tah počítače
def bot_move():
    global turn
    # Umělá pauza pro lepší zážitek z hraní
    pygame.time.wait(500)
    # Náhodný výběr volného pole
    while True:
        row = random.randint(0, ROW_COUNT-1)
        col = random.randint(0, COLUMN_COUNT-1)
        if board[row][col] == ' ':
            board[row][col] = turn
            draw_board()
            if is_game_over():
                message = FONT.render("Hra skončila!", True, (0, 0, 0))
                message_rect = message.get_rect(center=(WIDTH/2, HEIGHT/2))
                screen.blit(message, message_rect)
                pygame.display.update()
            else:
                if turn == 'X':
                    turn = 'O'
                else:
                    turn = 'X'
            break

# Spuštění nové hry
new_game()

# Hlavní smyčka hry
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            square = get_square(pygame.mouse.get_pos())
            if square:
                player_move(square)
