import speech_recognition as sr
import pyttsx3
import webbrowser
import tkinter as tk

# initialize text-to-speech converter
engine = pyttsx3.init()

# function to synthesize speech from text
def speak(text):
    engine.say(text)
    engine.runAndWait()

# function to recognize speech and return text
def get_text():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something...")
        audio = r.listen(source)
        try:
            text = r.recognize_google(audio)
            print("Recognized: " + text)
        except:
            print("Not recognized")
            text = ""
        return text.lower()

# function to handle user input
def handle_input():
    user_input = user_entry.get().lower()
    if "open google" in user_input:
        webbrowser.open("https://www.google.com/")
        speak("Opening Google...")
    elif "open drive" in user_input:
        webbrowser.open("https://drive.google.com/")
        speak("Opening Drive...")
    elif "open docs" in user_input:
        webbrowser.open("https://docs.google.com/")
        speak("Opening Docs...")
    elif "open sheets" in user_input:
        webbrowser.open("https://sheets.google.com/")
        speak("Opening Sheets...")
    elif "open slides" in user_input:
        webbrowser.open("https://slides.google.com/")
        speak("Opening Slides...")
    elif "open calendar" in user_input:
        webbrowser.open("https://calendar.google.com/")
        speak("Opening Calendar...")
    elif "open maps" in user_input:
        webbrowser.open("https://www.google.com/maps")
        speak("Opening Maps...")
    elif "open news" in user_input:
        webbrowser.open("https://news.google.com/")
        speak("Opening News...")
    else:
        speak("Sorry, I don't understand. Please try again.")

# function to handle speech recognition
def recognize_speech():
    user_input = get_text()
    if user_input == "":
        speak("Sorry, I didn't catch that. Please try again.")
    else:
        user_entry.delete(0, tk.END)
        user_entry.insert(0, user_input)
        handle_input()

# create main window
root = tk.Tk()
root.title("Voice Assistant")

# create user input field
user_entry = tk.Entry(root, width=50)
user_entry.pack(padx=10, pady=10)

# create submit button
submit_button = tk.Button(root, text="Submit", command=handle_input)
submit_button.pack(padx=10, pady=10)

# create speech recognition button
speech_button = tk.Button(root, text="Speak", command=recognize_speech)
speech_button.pack(padx=10, pady=10)

# start program
speak("Hello, I am a voice assistant Python Virtual Mechine! How can I help you?")
root.mainloop()
