import tkinter as tk

class StopWatch(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.time = 0
        self.running = False
        self.create_widgets()

    def create_widgets(self):
        self.time_label = tk.Label(self.master, text='00:00.00', font=('Helvetica', 48))
        self.time_label.pack(pady=10)
        self.start_button = tk.Button(self.master, text='Start', command=self.start_stop)
        self.start_button.pack(pady=5)
        self.reset_button = tk.Button(self.master, text='Reset', command=self.reset)
        self.reset_button.pack()

    def start_stop(self):
        self.running = not self.running
        if self.running:
            self.start_button.config(text='Stop')
            self.timer()
        else:
            self.start_button.config(text='Start')

    def timer(self):
        if self.running:
            self.time += 0.01
            minutes, seconds = divmod(self.time, 60)
            hours, minutes = divmod(minutes, 60)
            self.time_label.config(text=f'{hours:02.0f}:{minutes:02.0f}:{seconds:04.2f}')
            self.after(10, self.timer)

    def reset(self):
        self.time = 0
        self.running = False
        self.start_button.config(text='Start')
        self.time_label.config(text='00:00.00')

root = tk.Tk()
root.title('Stopky')
sw = StopWatch(master=root)
sw.pack()
root.mainloop()
