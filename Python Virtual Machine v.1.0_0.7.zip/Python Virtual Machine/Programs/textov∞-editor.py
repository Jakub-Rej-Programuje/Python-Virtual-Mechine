import tkinter as tk
from tkinter import filedialog

class TextEditor:
    def __init__(self, master):
        self.master = master
        master.title("Textový editor")

        # Vytvoření menu
        self.menu = tk.Menu(master)
        self.file_menu = tk.Menu(self.menu, tearoff=0)
        self.file_menu.add_command(label="Nový", command=self.new_file)
        self.file_menu.add_command(label="Otevřít", command=self.open_file)
        self.file_menu.add_command(label="Uložit", command=self.save_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Konec", command=master.quit)
        self.menu.add_cascade(label="Soubor", menu=self.file_menu)
        master.config(menu=self.menu)

        # Vytvoření textového pole
        self.text = tk.Text(master)
        self.text.pack()

        # Proměnná pro uložení aktuálního souboru
        self.current_file = None

    def new_file(self):
        self.text.delete("1.0", tk.END)
        self.current_file = None

    def open_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.current_file = file_path
            with open(file_path, "r") as file:
                file_content = file.read()
                self.text.delete("1.0", tk.END)
                self.text.insert(tk.END, file_content)

    def save_file(self):
        if self.current_file:
            with open(self.current_file, "w") as file:
                file.write(self.text.get("1.0", tk.END))
        else:
            file_path = filedialog.asksaveasfilename()
            if file_path:
                self.current_file = file_path
                with open(file_path, "w") as file:
                    file.write(self.text.get("1.0", tk.END))

# Vytvoření instance aplikace Tkinter
root = tk.Tk()
app = TextEditor(root)
root.mainloop()
