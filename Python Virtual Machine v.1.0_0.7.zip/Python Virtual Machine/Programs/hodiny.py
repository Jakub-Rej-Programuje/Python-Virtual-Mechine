import tkinter as tk
import time

class Clock(tk.Label):
    def __init__(self, parent=None, **kw):
        tk.Label.__init__(self, parent, kw)
        self.display_time()
        self.after(1000, self.display_time)

    def display_time(self):
        time_now = time.strftime('%H:%M:%S')
        self.config(text=time_now)
        self.after(1000, self.display_time)

root = tk.Tk()
root.title('Hodiny')
clock = Clock(root, font=('arial', 50, 'bold'), bg='white', fg='black')
clock.pack(fill='both', expand=1)
root.mainloop()
