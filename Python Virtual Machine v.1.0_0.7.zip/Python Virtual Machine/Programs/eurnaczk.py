import requests
import tkinter as tk

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        self.amount_label = tk.Label(self, text="Částka v CZK:")
        self.amount_label.pack(side="top")
        self.amount_entry = tk.Entry(self)
        self.amount_entry.pack(side="top")

        self.convert_button = tk.Button(self, text="CZK → EUR", command=self.convert_czk_to_eur)
        self.convert_button.pack(side="top")

        self.result_label = tk.Label(self, text="")
        self.result_label.pack(side="top")

    def convert_czk_to_eur(self):
        # Získání aktuálního kurzu CZK/EUR
        url = "https://api.exchangerate-api.com/v4/latest/CZK"
        response = requests.get(url)
        data = response.json()
        czk_to_eur_rate = data["rates"]["EUR"]

        # Výpočet převodu
        czk_amount = float(self.amount_entry.get())
        eur_amount = round(czk_amount / czk_to_eur_rate, 2)

        # Zobrazení výsledku
        result_text = f"{czk_amount:.2f} CZK = {eur_amount:.2f} EUR"
        self.result_label.configure(text=result_text)

# Vytvoření instance aplikace Tkinter
root = tk.Tk()
app = Application(master=root)
app.mainloop()
