import pygame
import random

# Definice konstant
WIDTH = 500
HEIGHT = 500
FPS = 60
CIRCLE_RADIUS = 25

# Inicializace Pygame modulu
pygame.init()

# Vytvoření okna
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Shooter")

# Definice barev
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Definice hodnot
score = 0

# Funkce pro vytvoření náhodného kruhu
def create_circle():
    x = random.randint(0, WIDTH)
    y = random.randint(0, HEIGHT)
    return (x, y)

# Funkce pro vykreslení kruhu na obrazovce
def draw_circle(circle):
    x, y = circle
    pygame.draw.circle(screen, RED, (x, y), CIRCLE_RADIUS)

# Funkce pro získání vzdálenosti mezi dvěma body
def distance(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

# Funkce pro spuštění nové hry
def new_game():
    global circles, score
    circles = []
    score = 0
    pygame.time.set_timer(pygame.USEREVENT, 1000)
    draw_board()

# Funkce pro vykreslení skóre na obrazovku
def draw_score():
    font = pygame.font.Font(None, 36)
    text = font.render("Score: " + str(score), True, BLACK)
    text_rect = text.get_rect()
    text_rect.topright = (WIDTH - 10, 10)
    screen.blit(text, text_rect)

# Funkce pro vykreslení hry na obrazovku
def draw_board():
    screen.fill(WHITE)
    for circle in circles:
        draw_circle(circle)
    draw_score()
    pygame.display.update()

# Spuštění nové hry
new_game()

# Hlavní smyčka hry
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.USEREVENT:
            circles.append(create_circle())
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            for circle in circles:
                if distance(pos, circle) <= CIRCLE_RADIUS:
                    circles.remove(circle)
                    score += 1
            draw_board()

    draw_board()

    # Obnovování obrazovky
    pygame.display.flip()

# Ukončení Pygame modulu
pygame.quit()
