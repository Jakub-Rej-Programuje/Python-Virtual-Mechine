import tkinter as tk
from tkinter import filedialog
import pygame
import time

# Inicializace knihovny Pygame
pygame.init()

# Vytvoření hlavního okna
window = tk.Tk()
window.title("Přehrávač písní")
window.minsize(width=150, height=70)
# Proměnná pro uchování délky trvání písně
song_length = 0

# Proměnná pro určení, zda je přehrávání písně pozastaveno nebo ne
paused = False

# Funkce pro výběr souboru s písní
def select_song():
    file_path = filedialog.askopenfilename()
    return file_path

# Funkce pro přehrání vybrané písně
def play_song():
    global song_length, paused
    file_path = select_song()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()
    song_length = pygame.mixer.Sound(file_path).get_length()
    paused = False
    update_song_length()

# Funkce pro pozastavení nebo obnovení přehrávání písně
def toggle_pause():
    global paused
    if paused:
        pygame.mixer.music.unpause()
        paused = False
        pause_button.configure(text="Pozastavit")
    else:
        pygame.mixer.music.pause()
        paused = True
        pause_button.configure(text="Pokračovat")

# Funkce pro zobrazení délky trvání písně
def update_song_length():
    global song_length
    while pygame.mixer.music.get_busy():
        elapsed_time = pygame.mixer.music.get_pos() / 1000
        time_remaining = song_length - elapsed_time
        time_label.configure(text="Zbývající čas: {:.2f} s".format(time_remaining))
        window.update()
        time.sleep(0.1)

# Tlačítko pro výběr a přehrání písně
play_button = tk.Button(window, text="Vybrat a přehrát píseň", command=play_song)
play_button.pack()

# Tlačítko pro pozastavení/odpozastavení přehrávání písně
pause_button = tk.Button(window, text="Pozastavit", command=toggle_pause)
pause_button.pack()

# Label pro zobrazení zbývajícího času písně
time_label = tk.Label(window, text="Zbývající čas: 0 s")
time_label.pack()

# Spuštění hlavní smyčky pro zobrazení okna
window.mainloop()

# Ukončení knihovny Pygame
pygame.quit()
