import tkinter as tk

class Calculator:
    def __init__(self, master):
        self.master = master
        self.master.title("Kalkulačka")
        
        # Vstupní pole pro zobrazení výsledku
        self.entry = tk.Entry(self.master, width=20, font=("Arial", 16))
        self.entry.grid(row=0, column=0, columnspan=4, padx=5, pady=5)
        
        # Tlačítka pro čísla
        numbers = [
            "7", "8", "9",
            "4", "5", "6",
            "1", "2", "3",
            "0", ".", "="
        ]
        
        r = 1
        c = 0
        for number in numbers:
            button = tk.Button(self.master, text=number, width=5, height=2,
                               font=("Arial", 12),
                               command=lambda number=number: self.click(number))
            button.grid(row=r, column=c, padx=5, pady=5)
            c += 1
            if c > 2:
                c = 0
                r += 1
                
        # Tlačítka pro operace
        operators = [
            "+", "-", "*", "/",
            "(", ")", "C", "AC"
        ]
        
        r = 1
        c = 3
        for operator in operators:
            button = tk.Button(self.master, text=operator, width=5, height=2,
                               font=("Arial", 12),
                               command=lambda operator=operator: self.click(operator))
            button.grid(row=r, column=c, padx=5, pady=5)
            r += 1
                
    def click(self, number):
        if number == "C":
            self.entry.delete(-1)
        elif number == "AC":
            self.entry.delete(0, "end")
        elif number == "=":
            current = self.entry.get()
            try:
                result = str(eval(current))
            except:
                result = "Error"
            self.entry.delete(0, "end")
            self.entry.insert(0, result)
        else:
            current = self.entry.get()
            self.entry.delete(0, "end")
            self.entry.insert(0, str(current) + str(number))

root = tk.Tk()
calculator = Calculator(root)
root.mainloop()
