import tkinter as tk
from tkinter import filedialog
import shutil
import os

class StorageApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Internetové úložiště")
        self.master.geometry("400x400")

        # Label a Entry pro název složky
        self.folder_label = tk.Label(master, text="Název složky:")
        self.folder_label.pack(pady=10)
        self.folder_entry = tk.Entry(master)
        self.folder_entry.pack(pady=10)

        # Tlačítka pro akce se soubory
        self.add_button = tk.Button(master, text="Přidat soubor", command=self.add_file)
        self.add_button.pack(pady=10)
        self.delete_button = tk.Button(master, text="Smazat soubor", command=self.delete_file)
        self.delete_button.pack(pady=10)
        self.download_button = tk.Button(master, text="Stáhnout soubor", command=self.download_file)
        self.download_button.pack(pady=10)

        # Listbox pro seznam souborů
        self.file_listbox = tk.Listbox(master)
        self.file_listbox.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Načtení uložených souborů
        self.load_files()

    def add_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            file_name = os.path.basename(file_path)
            folder_name = self.folder_entry.get() or 'my_files'
            destination = os.path.join(folder_name, file_name)
            shutil.copy(file_path, destination)
            self.file_listbox.insert(tk.END, file_name)

    def delete_file(self):
        selected_file = self.file_listbox.curselection()
        if selected_file:
            file_name = self.file_listbox.get(selected_file)
            folder_name = self.folder_entry.get() or 'my_files'
            file_path = os.path.join(folder_name, file_name)
            os.remove(file_path)
            self.file_listbox.delete(selected_file)

    def download_file(self):
        selected_file = self.file_listbox.curselection()
        if selected_file:
            file_name = self.file_listbox.get(selected_file)
            folder_name = self.folder_entry.get() or 'my_files'
            file_path = os.path.join(folder_name, file_name)
            file_destination = filedialog.asksaveasfilename(initialfile=file_name)
            if file_destination:
                shutil.copy(file_path, file_destination)

    def load_files(self):
        folder_name = self.folder_entry.get() or 'my_files'
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)
        for file_name in os.listdir(folder_name):
            self.file_listbox.insert(tk.END, file_name)

if __name__ == '__main__':
    root = tk.Tk()
    app = StorageApp(root)
    root.mainloop()
